from setuptools import setup, find_packages

setup(
    name = 'mypackage',
    version = 1.0,
    author='Buhari Shehu',
    url='tbd'
)